const FoodiesAPI = {
  async getAllCatalogs() {
    try {
      const response = await fetch(
        "https://story-api.dicoding.dev/v1/catalogs",
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer YOUR_ACCESS_TOKEN`, // Ganti dengan token akses yang valid
          },
        }
      );

      const data = await response.json();

      // Memastikan status respons valid
      if (!response.ok) {
        throw new Error(data.message || "Gagal mengambil data.");
      }

      return {
        ok: true,
        message: data.message,
        data: data.catalogs, // Sesuaikan nama key ini dengan struktur respons API
      };
    } catch (error) {
      return {
        ok: false,
        message: error.message || "Terjadi kesalahan saat mengambil data.",
      };
    }
  },
};

export default FoodiesAPI;
